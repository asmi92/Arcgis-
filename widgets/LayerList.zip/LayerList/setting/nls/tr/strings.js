define({
  "showLegend": "Gösterimi göster",
  "controlPopupMenuTitle": "Katman içerik menüsünde gösterilecek eylemleri seçin.",
  "zoomto": "Yakınlaştır",
  "transparency": "Şeffaflık",
  "controlPopup": "Açılır Pencereyi Etkinleştir / Devre Dışı Bırak",
  "moveUpAndDown": "Yukarı taşı / Aşağı taşı",
  "attributeTable": "Öznitelik Tablosunu Aç",
  "url": "Açıklama / Öğe Ayrıntılarını Göster / İndir",
  "layerSelectorTitle": "Listede gösterilecek katmanları seçin."
});