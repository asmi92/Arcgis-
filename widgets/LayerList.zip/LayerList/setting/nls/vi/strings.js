define({
  "showLegend": "Hiện chú giải",
  "controlPopupMenuTitle": "Chọn tác vụ sẽ được hiển thị trên menu ngữ cảnh lớp.",
  "zoomto": "Phóng tới",
  "transparency": "Độ trong suốt",
  "controlPopup": "Bật / Tắt Cửa sổ pop-up",
  "moveUpAndDown": "Di chuyển lên / Di chuyển xuống",
  "attributeTable": "Mở Bảng Thuộc tính",
  "url": "Thông tin mô tả / Hiện Thông tin chi tiết Mục / Tải về",
  "layerSelectorTitle": "Chọn lớp sẽ được hiển thị trên danh sách."
});