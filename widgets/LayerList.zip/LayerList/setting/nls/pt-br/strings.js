define({
  "showLegend": "Mostrar legenda",
  "controlPopupMenuTitle": "Escolha quais ações serão mostradas no menu de contexto da camada.",
  "zoomto": "Zoom para",
  "transparency": "Transparência",
  "controlPopup": "Habilitar / Desabilitar Pop-up",
  "moveUpAndDown": "Mover para Cima / Mover para Baixo",
  "attributeTable": "Abrir Tabela de Atributos",
  "url": "Descrição / Mostrar Detalhes do Item / Download",
  "layerSelectorTitle": "Escolha quais camadas serão mostradas na lista."
});