define({
  "showLegend": "Mostra legenda",
  "controlPopupMenuTitle": "Scegliere quali azioni verranno visualizzate sul menu contestuale del layer.",
  "zoomto": "Zoom a",
  "transparency": "Trasparenza",
  "controlPopup": "Abilita/Disabilita popup",
  "moveUpAndDown": "Sposta su/Sposta giù",
  "attributeTable": "Apri tabella attributi",
  "url": "Descrizione/Mostra dettagli elemento/Download",
  "layerSelectorTitle": "Scegliere quali layer verranno visualizzati nell'elenco."
});